import { Injectable } from "@nitrostack/core";
import { WeatherResult } from "./smartclaim.types.js";

@Injectable()
export class WeatherService {

    /**
     * Fetch historical weather for the accident date and time
     */
    async getHistoricalWeather(
        latitude: number,
        longitude: number,
        accidentDate: string,
        accidentTime: string
    ): Promise<WeatherResult> {

        try {

            // Example: "14:35" -> "14"
            const hour = accidentTime.split(":")[0];

            const url =
                `https://archive-api.open-meteo.com/v1/archive?` +
                `latitude=${latitude}` +
                `&longitude=${longitude}` +
                `&start_date=${accidentDate}` +
                `&end_date=${accidentDate}` +
                `&hourly=temperature_2m,weather_code,visibility`;

            const response = await fetch(url);

            if (!response.ok) {
                throw new Error("Unable to fetch historical weather.");
            }

            const data: any = await response.json();

            const index = data.hourly.time.findIndex(
                (time: string) => time.includes(`T${hour}:00`)
            );

            if (index === -1) {
                throw new Error("Weather data not available.");
            }

            return {
                condition: this.decodeWeatherCode(
                    data.hourly.weather_code[index]
                ),
                temperature: data.hourly.temperature_2m[index],
                visibility: data.hourly.visibility[index]
            };

        } catch (error) {

            console.error("Weather Service Error:", error);

            return {
                condition: "Unknown",
                temperature: 0,
                visibility: 0
            };
        }
    }

    /**
     * Convert Open-Meteo weather codes into readable text
     */
    private decodeWeatherCode(code: number): string {

        switch (code) {

            case 0:
                return "Clear Sky";

            case 1:
            case 2:
            case 3:
                return "Cloudy";

            case 45:
            case 48:
                return "Fog";

            case 51:
            case 53:
            case 55:
                return "Drizzle";

            case 61:
            case 63:
            case 65:
                return "Rain";

            case 71:
            case 73:
            case 75:
                return "Snow";

            case 80:
            case 81:
            case 82:
                return "Rain Showers";

            case 95:
                return "Thunderstorm";

            default:
                return "Unknown";
        }
    }
}