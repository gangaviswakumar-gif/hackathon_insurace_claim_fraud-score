import { Injectable } from "@nitrostack/core";
import { Pool } from "pg";

@Injectable()
export class DatabaseService {

    private pool: Pool;

    constructor() {

        this.pool = new Pool({

            host: process.env.DATABASE_HOST,

            port: Number(process.env.DATABASE_PORT),

            database: process.env.DATABASE_NAME,

            user: process.env.DATABASE_USER,

            password: process.env.DATABASE_PASSWORD,

        });

    }

    async query(text: string, params?: any[]) {

        const result = await this.pool.query(text, params);

        return result;

    }

}