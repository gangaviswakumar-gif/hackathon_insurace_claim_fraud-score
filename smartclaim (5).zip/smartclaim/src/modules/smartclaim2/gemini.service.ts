import { Injectable } from "@nitrostack/core";
import { GoogleGenAI } from "@google/genai";

import {
    DamageAnalysis,
    BillAnalysis
} from "./smartclaim.types.js";

import {
    DAMAGE_PROMPT,
    BILL_PROMPT
} from "./prompts.js";

@Injectable()
export class GeminiService {

    private ai: GoogleGenAI;

    private readonly MODEL = "gemini-2.5-flash";

    constructor() {

        this.ai = new GoogleGenAI({
            apiKey: process.env.GEMINI_API_KEY!
        });

    }

    /**
     * Analyze uploaded vehicle damage images
     */
    async analyzeDamage(
        images: string[]
    ): Promise<DamageAnalysis> {

        if (!images || images.length === 0) {

            return {

                severity: "Low",

                estimatedRepairCost: 0,

                confidence: 0,

                observations: [
                    "No damage images uploaded."
                ]

            };

        }

        const imageParts = images.map((img) => ({

            inlineData: {

                mimeType: "image/jpeg",

                data: img

            }

        }));

        const response = await this.ai.models.generateContent({

            model: this.MODEL,

            contents: [

                {

                    role: "user",

                    parts: [

                        ...imageParts,

                        {

                            text: DAMAGE_PROMPT

                        }

                    ]

                }

            ]

        });

        const text = response.text ?? "";

        try {

            const cleaned = text
                .replace(/```json/g, "")
                .replace(/```/g, "")
                .trim();

            return JSON.parse(cleaned);

        } catch (error) {

            console.error(
                "Gemini Damage Parse Error:",
                error
            );

            return {

                severity: "Low",

                estimatedRepairCost: 0,

                confidence: 0,

                observations: [
                    "Unable to parse Gemini response."
                ]

            };

        }

    }

    /**
     * Analyze uploaded repair bill
     */
    async analyzeRepairBill(
        image?: string
    ): Promise<BillAnalysis> {

        if (!image) {

            return {

                workshopName: "Not Provided",

                billAmount: 0,

                billDate: "",

                isReadable: false

            };

        }

        const response = await this.ai.models.generateContent({

            model: this.MODEL,

            contents: [

                {

                    role: "user",

                    parts: [

                        {

                            inlineData: {

                                mimeType: "image/jpeg",

                                data: image

                            }

                        },

                        {

                            text: BILL_PROMPT

                        }

                    ]

                }

            ]

        });

        const text = response.text ?? "";

        try {

            const cleaned = text
                .replace(/```json/g, "")
                .replace(/```/g, "")
                .trim();

            return JSON.parse(cleaned);

        } catch (error) {

            console.error(
                "Gemini Bill Parse Error:",
                error
            );

            return {

                workshopName: "Unknown",

                billAmount: 0,

                billDate: "",

                isReadable: false

            };

        }

    }

}