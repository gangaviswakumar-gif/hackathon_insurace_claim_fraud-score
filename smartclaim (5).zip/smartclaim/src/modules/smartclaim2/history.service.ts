import { Injectable } from "@nitrostack/core";

import { DatabaseService } from "./database.service.js";

import { CustomerHistory } from "./smartclaim.types.js";

@Injectable({
    deps: [DatabaseService]
})
export class HistoryService {

    constructor(
        private readonly database: DatabaseService
    ) {}

    async getCustomerHistory(
        customerId: string
    ): Promise<CustomerHistory> {

        try {

            const result =
                await this.database.query(

                    `
                    SELECT

                        COUNT(*) AS previous_claims,

                        COALESCE(SUM(claim_amount),0) AS total_claim_amount,

                        COUNT(*) FILTER (
                            WHERE fraud_flag = true
                        ) AS suspicious_claims

                    FROM claims

                    WHERE customer_id = $1
                    `,

                    [customerId]

                );

            const row = result.rows[0];

            return {

                previousClaims:
                    Number(row.previous_claims),

                totalClaimAmount:
                    Number(row.total_claim_amount),

                suspiciousClaims:
                    Number(row.suspicious_claims)

            };

        } catch (error) {

            console.error(
                "Database Error:",
                error
            );

            return {

                previousClaims: 0,

                totalClaimAmount: 0,

                suspiciousClaims: 0

            };

        }

    }

}