import { Injectable } from "@nitrostack/core";
import { LocationResult } from "./smartclaim.types.js";

@Injectable()
export class LocationService {

    /**
     * Verify accident location using OpenStreetMap Nominatim API
     */
    async verifyLocation(location: string): Promise<LocationResult> {

        try {

            const url =
                `https://nominatim.openstreetmap.org/search?` +
                `q=${encodeURIComponent(location)}` +
                `&format=json&limit=1`;

            const response = await fetch(url, {
                headers: {
                    "User-Agent": "SmartClaim/1.0"
                }
            });

            if (!response.ok) {
                throw new Error("Failed to fetch location");
            }

            const data = (await response.json()) as any[];

            if (data.length === 0) {
                return {
                    verified: false,
                    latitude: 0,
                    longitude: 0
                };
            }

            return {
                verified: true,
                latitude: parseFloat(data[0].lat),
                longitude: parseFloat(data[0].lon)
            };

        } catch (error) {

            console.error("Location verification failed:", error);

            return {
                verified: false,
                latitude: 0,
                longitude: 0
            };
        }
    }
}