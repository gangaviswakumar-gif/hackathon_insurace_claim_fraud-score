import { Injectable } from "@nitrostack/core";

import {
    WeatherResult,
    LocationResult,
    DamageAnalysis,
    CustomerHistory,
    FraudReport
} from "./smartclaim.types.js";

@Injectable()
export class RiskService {

    calculateRisk(
        claimDescription: string,
        weather: WeatherResult,
        location: LocationResult,
        damage: DamageAnalysis,
        history: CustomerHistory,
        claimAmount: number
    ): FraudReport {

        let fraudScore = 0;
        const reasons: string[] = [];

        //------------------------------------------
        // Customer History
        //------------------------------------------

        if (history.previousClaims >= 3) {
            fraudScore += 20;
            reasons.push("Customer has multiple previous claims.");
        }

        if (history.suspiciousClaims > 0) {
            fraudScore += 25;
            reasons.push("Customer has previous suspicious claims.");
        }

        //------------------------------------------
        // Location Verification
        //------------------------------------------

        if (!location.verified) {
            fraudScore += 20;
            reasons.push("Accident location could not be verified.");
        }

        //------------------------------------------
        // Weather Consistency
        //------------------------------------------

        const description = claimDescription.toLowerCase();

        const mentionsRain =
            description.includes("rain") ||
            description.includes("slippery") ||
            description.includes("wet road") ||
            description.includes("skid");

        if (
            mentionsRain &&
            weather.condition === "Clear Sky"
        ) {
            fraudScore += 15;
            reasons.push(
                "Claim description is inconsistent with historical weather."
            );
        }

        //------------------------------------------
        // Damage Cost Comparison
        //------------------------------------------

        if (
            claimAmount >
            damage.estimatedRepairCost * 1.5
        ) {
            fraudScore += 25;

            reasons.push(
                "Claim amount is significantly higher than estimated repair cost."
            );
        }

        //------------------------------------------
        // AI Confidence
        //------------------------------------------

        if (damage.confidence < 60) {

            fraudScore += 10;

            reasons.push(
                "Damage analysis confidence is low."
            );
        }

        //------------------------------------------
        // Damage Severity
        //------------------------------------------

        if (
            damage.severity === "Low" &&
            claimAmount > 100000
        ) {

            fraudScore += 20;

            reasons.push(
                "Claim amount appears high for the detected damage severity."
            );
        }

        //------------------------------------------
        // Limit Score
        //------------------------------------------

        fraudScore = Math.min(fraudScore, 100);

        //------------------------------------------
        // Risk Level
        //------------------------------------------

        let riskLevel: "Low" | "Medium" | "High";

        if (fraudScore < 35) {

            riskLevel = "Low";

        } else if (fraudScore < 70) {

            riskLevel = "Medium";

        } else {

            riskLevel = "High";
        }

        //------------------------------------------
        // Recommendation
        //------------------------------------------

        let recommendation: string;

        switch (riskLevel) {

            case "Low":
                recommendation =
                    "Claim appears genuine. Proceed with standard processing.";
                break;

            case "Medium":
                recommendation =
                    "Manual review recommended before approval.";
                break;

            default:
                recommendation =
                    "High fraud risk. Detailed investigation recommended.";
        }

        //------------------------------------------

        return {

            fraudScore,

            riskLevel,

            confidence: damage.confidence,

            recommendation,

            reasons

        };

    }

}