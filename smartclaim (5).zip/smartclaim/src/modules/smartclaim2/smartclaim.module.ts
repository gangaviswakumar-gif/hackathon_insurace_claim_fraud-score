import { DatabaseService } from "./database.service.js";
import { Module } from "@nitrostack/core";

import { SmartClaimTools } from "./smartclaim.tools.js";

import { GeminiService } from "./gemini.service.js";
import { WeatherService } from "./weather.service.js";
import { LocationService } from "./location.service.js";
import { HistoryService } from "./history.service.js";
import { RiskService } from "./risk.service.js";
import { ReportService } from "./report.service.js";

@Module({
    name: "smartclaim",

    description:
        "AI-powered insurance claim fraud detection system",

    providers: [
        DatabaseService,
        GeminiService,
        WeatherService,
        LocationService,
        HistoryService,
        RiskService,
        ReportService,
        SmartClaimTools
    ]
})
export class SmartClaimModule {}