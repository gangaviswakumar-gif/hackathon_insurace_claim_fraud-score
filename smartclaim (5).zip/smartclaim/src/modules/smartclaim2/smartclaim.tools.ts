import {
    ToolDecorator as Tool,
    Injectable,
    ExecutionContext,
    z
} from "@nitrostack/core";

import { LocationService } from "./location.service.js";
import { WeatherService } from "./weather.service.js";
import { GeminiService } from "./gemini.service.js";
import { HistoryService } from "./history.service.js";
import { RiskService } from "./risk.service.js";
import { ReportService } from "./report.service.js";

const AnalyzeClaimSchema = z.object({

    customerId: z.string(),

    customerName: z.string(),

    policyNumber: z.string(),

    location: z.string(),

    accidentDate: z.string(),

    accidentTime: z.string(),

    description: z.string(),

    claimAmount: z.number(),

    damageImages: z.array(z.string()).optional(),

    repairBillImage: z.string().optional(),

    accidentVideo: z.string().optional()

});

@Injectable({
    deps: [
        LocationService,
        WeatherService,
        GeminiService,
        HistoryService,
        RiskService,
        ReportService
    ]
})
export class SmartClaimTools {

    constructor(

        private readonly locationService: LocationService,

        private readonly weatherService: WeatherService,

        private readonly geminiService: GeminiService,

        private readonly historyService: HistoryService,

        private readonly riskService: RiskService,

        private readonly reportService: ReportService

    ) { }

@Tool
({
  name: "analyze_claim",
  description: "Analyze an insurance claim and generate a fraud risk assessment.",
  inputSchema: AnalyzeClaimSchema
})
    async analyzeClaim(
        args: z.infer<typeof AnalyzeClaimSchema>,
        ctx: ExecutionContext
    ) {

        ctx.logger.info("Starting SmartClaim Analysis");

        //-----------------------------------------
        // STEP 1 : Verify Accident Location
        //-----------------------------------------

        const location =
            await this.locationService.verifyLocation(
                args.location
            );

        //-----------------------------------------
        // STEP 2 : Historical Weather
        //-----------------------------------------

        const weather =
            await this.weatherService.getHistoricalWeather(

                location.latitude,

                location.longitude,

                args.accidentDate,

                args.accidentTime

            );

        //-----------------------------------------
        // STEP 3 : Customer Claim History
        //-----------------------------------------

        const history =
            await this.historyService.getCustomerHistory(
                args.customerId
            );

        //-----------------------------------------
        // STEP 4 : AI Damage Analysis
        //-----------------------------------------

        const damage =
            await this.geminiService.analyzeDamage(
                args.damageImages ?? []
            );

        //-----------------------------------------
        // STEP 5 : Repair Bill Analysis
        //-----------------------------------------

        const bill =
            await this.geminiService.analyzeRepairBill(
                args.repairBillImage
            );

        //-----------------------------------------
        // STEP 6 : Fraud Risk Calculation
        //-----------------------------------------

        const fraud =
            this.riskService.calculateRisk(

                args.description,

                weather,

                location,

                damage,

                history,

                args.claimAmount

            );

        //-----------------------------------------
        // STEP 7 : Generate Final Report
        //-----------------------------------------

        const report =
            this.reportService.generateReport(

                fraud,

                damage,

                weather,

                history,

                location,

                bill

            );

        ctx.logger.info("SmartClaim Analysis Completed");

        return report;

    }

}