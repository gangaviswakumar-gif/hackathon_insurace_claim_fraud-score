// src/modules/smartclaim/smartclaim.types.ts

export interface ClaimRequest {
    customerId: string;
    customerName: string;
    policyNumber: string;

    location: string;

    accidentDate: string;
    accidentTime: string;

    description: string;

    claimAmount: number;

    damageImages?: string[];

    repairBillImage?: string;

    accidentVideo?: string;
}

export interface WeatherResult {
    condition: string;
    temperature: number;
    visibility: number;
}

export interface LocationResult {
    latitude: number;
    longitude: number;
    verified: boolean;
}

export interface DamageAnalysis {
    severity: "Low" | "Medium" | "High";

    estimatedRepairCost: number;

    confidence: number;

    observations: string[];
}

export interface CustomerHistory {
    previousClaims: number;

    totalClaimAmount: number;

    suspiciousClaims: number;
}

export interface FraudReport {

    fraudScore: number;

    riskLevel: "Low" | "Medium" | "High";

    confidence: number;

    recommendation: string;

    reasons: string[];
}export interface BillAnalysis {

    workshopName: string;

    billAmount: number;

    billDate: string;

    isReadable: boolean;

}