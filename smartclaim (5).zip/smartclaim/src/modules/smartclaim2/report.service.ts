import { Injectable } from "@nitrostack/core";

import {
    FraudReport,
    DamageAnalysis,
    WeatherResult,
    CustomerHistory,
    LocationResult,
    BillAnalysis
} from "./smartclaim.types.js";

@Injectable()
export class ReportService {

    generateReport(
        fraud: FraudReport,
        damage: DamageAnalysis,
        weather: WeatherResult,
        history: CustomerHistory,
        location: LocationResult,
        bill: BillAnalysis
    ) {

        return {

            success: true,

            timestamp: new Date().toISOString(),

            fraudAnalysis: {

                fraudScore: fraud.fraudScore,

                riskLevel: fraud.riskLevel,

                confidence: fraud.confidence,

                recommendation: fraud.recommendation,

                reasons: fraud.reasons

            },

            damageAnalysis: {

    severity: damage.severity,

    estimatedRepairCost:
        damage.estimatedRepairCost,

    confidence:
        damage.confidence,

    observations:
        damage.observations

},
            billAnalysis: {

                workshopName:
                    bill.workshopName,

                billAmount:
                    bill.billAmount,

                billDate:
                    bill.billDate,

                isReadable:
                    bill.isReadable

            },

            weather: {

                condition:
                    weather.condition,

                temperature:
                    weather.temperature,

                visibility:
                    weather.visibility

            },

            customerHistory: {

                previousClaims:
                    history.previousClaims,

                suspiciousClaims:
                    history.suspiciousClaims,

                totalClaimAmount:
                    history.totalClaimAmount

            },

            location: {

                verified:
                    location.verified,

                latitude:
                    location.latitude,

                longitude:
                    location.longitude

            }

        };

    }

}